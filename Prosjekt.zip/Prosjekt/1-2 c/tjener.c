#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/sendfile.h>
#include <signal.h>
#include <dirent.h>

#define MIMETYPE "mime-types.tsv"
#define LOKAL_PORT 80
#define BAK_LOGG 10 // St�rrelse p� for k� ventende foresp�rsler

struct sockaddr_in  lok_adr;
struct stat sb;
int sd, ny_sd, send_fd;
long valread;
off_t offset = 0L;
char *p;
char filename[100] = "/";
char x[100] = "/";

void kataloglisting();

int get_type(char x[])
{
	int a = 0;
	char* check = strchr(x, '.');

	if(check != NULL)
	{
		char *ext = strrchr(x, '.');
		ext++;

		char t[10][10] = {"html", "txt", "png", "svg", "xml", "css", "js", "json", "xsl", "xslt"};

		for(int i=0; i < 10; i++)
		{
			if(strcmp(ext, t[i]) == 0)
			a = 1;
		}
	}

	return a;
}

char * get_mime_type(char *name)
{
	char *ext = strrchr(name, '.');
	char delimiters[] = " ";
	char *mime_type = NULL;
	mime_type = malloc (128 * sizeof(char)) ;
	char line[128];
	char *token;
	int line_counter = 1;
	ext++; // skip the '.';
	FILE *mime_type_file = fopen(MIMETYPE, "r");

	if (mime_type_file != NULL)
	{
		while(fgets(line, sizeof line, mime_type_file) != NULL)
		{
			if (line_counter > 1)
			{
				if((token = strtok(line,delimiters)) != NULL)
				{
					if(strcmp(token,ext) == 0)
					{
						token = strtok(NULL, delimiters);
						strcpy(mime_type, token);
						break;
					}
				}
			}
			line_counter++;
		}
		fclose( mime_type_file );
	}
	else
	{
		perror("open");
	}

	return mime_type;
}

int main (int argc, char **argv)
{

	if(0!=fork())
	{
		raise(SIGSTOP);
		exit(0);
	}
	else
	{
		setsid();
		signal(SIGHUP, SIG_IGN);

		if(0!=fork())
		{
			exit(0);
		}

		else
		{
			close(STDIN_FILENO);
			close(STDOUT_FILENO);
			close(STDERR_FILENO);

			int err = open("/var/error.log", O_RDWR|O_CREAT|O_APPEND, 0600);
			if (-1 == err) { perror("opening error.log"); return 255; }

			int save_err = dup(fileno(stderr));
			if (-1 == dup2(err, fileno(stderr))) { perror("cannot redirect stderr"); return 255; }

			chdir("/var/www");
			chroot("/var/www/");

			sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
			setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, &(int){ 1 }, sizeof(int));

			lok_adr.sin_family      = AF_INET;
			lok_adr.sin_port        = htons((u_short)LOKAL_PORT);
			lok_adr.sin_addr.s_addr = htonl(         INADDR_ANY);

			if ( 0==bind(sd, (struct sockaddr *)&lok_adr, sizeof(lok_adr)) )
				fprintf(stderr, "Prosess %d er knyttet til port %d.\n", getpid(), LOKAL_PORT);
			else
				exit(1);

			listen(sd, BAK_LOGG);

			setgid(1000);
			setuid(1000);

			while(1)
			{
				ny_sd = accept(sd, NULL, NULL);

				if(0==fork())
				{
					char buffer[100] = {0};
					char content_type[50];
					char test[50];
					valread = read(ny_sd , buffer, 99);
					p = strtok(buffer, " ");
					p = strtok(NULL, " ");
					int len;

					if (strcmp(p, "/") == 0)
					{
						kataloglisting();
						return 0;
					}

					strcat(filename, p);

					send_fd = open(filename, O_RDONLY);

					if (send_fd == -1)
					{
						if (get_type(filename) == 1)
						{
							send(ny_sd, "HTTP/1.1 404 Not Found\n\n", 23, 0);
							send(ny_sd, "Content-Type: text/plain\n", 25, 0);
							send(ny_sd, "\nDenne siden finnes ikke.\n", 26, 0);
							perror("File doesn't exist.");
						}
						else
						{
							send(ny_sd, "HTTP/1.1 415 Unsupported Media Type\n\n", 30, 0);
							send(ny_sd, "Content-Type: text/plain\n", 25, 0);
							send(ny_sd, "\nDen filtype stottes ikke.\n", 27, 0);
							perror("Bad mime-type.");
						}

					}
					else
					{
						if(send(ny_sd, "HTTP/1.1 200 OK\n", 16, 0) == -1)
						{
							perror("Error sending header: HTTP");
						}

						sprintf(content_type, "Content-Type: %s\n", get_mime_type(p));
						len = strlen(content_type);

						if(send(ny_sd, content_type, len, 0) == -1)
						{
							perror("Error sending header: content-type");
						}

						fstat(send_fd, &sb);

						if(sendfile(ny_sd, send_fd, &offset, sb.st_size) == -1)
						{
							perror("Failed to send file");
						}
					}

					close(send_fd);
					shutdown(ny_sd, SHUT_RDWR);
					exit(0);
				}

				else
				{
					close(ny_sd);
				}
			}
			fflush(stderr); close(err);

			return 0;
		}
	}
}

void kataloglisting()
{
	char *filsti = "/";
	struct stat       stat_buffer;
	struct dirent    *ent;
	DIR              *dir;
	char a[7000];

	if ((dir = opendir (filsti)) == NULL)
	{
		perror ("can't find PWD"); exit(1);
	}

	chdir(filsti);

	sprintf(a, "<!DOCTYPE html><html><head><title> Prosjekt DA-NAN3000 </title> <meta http-equiv=\"Content-Type\" content=\"text/html; charest-utf-8\" /><link rel=\"stylesheet\" type=\"text/css\" href=\"main.css\"></head>\
	<body><div class=\"wrapper\"><nav><ul><li> <a href=\"/\"><b>Prosjekt DA-NAN3000</b></a> </li><li> <a href=\"try.html\">Try CGI</a> </li><li> <a href=\"rest.html\">Try REST</a> </li><li> <a href=\"http://localhost:9000/some.html\">Try AJAX</a> </li></ul></nav><br><hr><h3>Katt</h3><hr><br>\
	<div style=\"text-align: center\" ><img src=\"katt.png\" style=\"width:350px;height:250px;\"></div><br><div id=\"clear\"><hr><h3> Kataloglisting </h3><hr><br><h1>Katalogen %s: </h1><table><tr><th>Rettigheter</th><th>UID     </th> <th>GID       </th><th>Navn</th></tr>");

	send(ny_sd,a,strlen(a),0);

	while ((ent = readdir (dir)) != NULL)
	{
		if ( !strcmp(ent->d_name, ".") || !strcmp(ent->d_name, ".."))
			continue;

		if (stat (ent->d_name, &stat_buffer) < 0)
			perror("Error finding files");

		sprintf(a,"<tr><td>%o</td><td>%d</td><td>%d</td><td><a href=\"%s%s\">%s</a></td></tr>\n",stat_buffer.st_mode & 0777, stat_buffer.st_uid,stat_buffer.st_gid, filsti,ent->d_name,ent->d_name);
		send(ny_sd,a,strlen(a),0);
	}

	sprintf(a, "</table></div><br><footer><div id=\"down\" ><p>Nataliia Kononenko</p></div><hr><p>2019 Prosjekt</p></footer></div></body></html>");

	send(ny_sd,a,strlen(a),0);

	closedir (dir);

}