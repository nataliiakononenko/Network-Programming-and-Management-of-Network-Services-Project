var sqlite3 = require('sqlite3').verbose()
var md5 = require('md5')

const DBSOURCE = "db.sqlite"

let db = new sqlite3.Database(DBSOURCE, (err) => {
    if (err) {
      // Cannot open database
      console.error(err.message)
      throw err
    }else{
        console.log('Connected to the SQLite database.')
        db.run(`CREATE TABLE bruker (
            brukerID INTEGER PRIMARY KEY,
            fornavn text, 
            etternavn text, 
            password text
            )`,
        (err) => {
            if (err) {
                // Table already created
            }else{
                // Table just created, creating some rows
                var insert = 'INSERT INTO bruker (brukerID, fornavn, etternavn, password) VALUES (?, ?,?,?)'
                db.run(insert, [1, "John","Smith",md5("admin123456")])
                db.run(insert, [2, "Jane","Dow",md5("user123456")])
            }
        });
		
        db.run(`CREATE TABLE sesjon (
            sesjonID INTEGER PRIMARY KEY AUTOINCREMENT,
            brukerID INTEGER,
			FOREIGN KEY(brukerID) REFERENCES bruker(brukerID)
            )`,
        (err) => {
            if (err) {
                // Table already created
            }else{
                // Table just created, creating some rows
      
            }
        });	
		
        db.run(`CREATE TABLE forfatter (
            forfatterID INTEGER PRIMARY KEY,
            fornavn text, 
			etternavn text,
			nasjonalitet text
            )`,
        (err) => {
            if (err) {
                // Table already created
            }else{
                // Table just created, creating some rows
                var insert = 'INSERT INTO forfatter (forfatterID, fornavn, etternavn, nasjonalitet) VALUES (?,?,?,?)'
                db.run(insert, [1, "Richard", "Pipes", "jewish"])
                db.run(insert, [2, "Michael", "Wolff", "american"])
            }
        });	

        db.run(`CREATE TABLE bok (
            bokID INTEGER PRIMARY KEY,
            titel text, 
			forfatterID INTEGER,
			FOREIGN KEY(forfatterID) REFERENCES forfatter(forfatterID)
            )`,
        (err) => {
            if (err) {
                // Table already created
            }else{
                // Table just created, creating some rows
                var insert = 'INSERT INTO bok (bokID, titel, forfatterID) VALUES (?,?,?)'
                db.run(insert, [1, "Memoir", 1])
                db.run(insert, [2, "Fire and Fury", 2])
            }
        });		
    }
});


module.exports = db
