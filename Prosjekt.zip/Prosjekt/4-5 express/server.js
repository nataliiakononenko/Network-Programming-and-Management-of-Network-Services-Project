// Create express app
var express = require("express")
var app = express()
var db = require("./database.js")
var md5 = require('md5')
var session = require("express-session")
var js2xmlparser = require("js2xmlparser") 
var jsonxml = require("jsontoxml")
var xml2js = require("xml2js")
var parser = new xml2js.Parser()

var xml = require('xml');

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
require('body-parser-xml')(bodyParser);
app.use(bodyParser.xml());

app.use(express.static('/var/www'));

app.use(function(req, res, next){
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', "GET, PUT, POST, DELETE");
    res.header('Access-Control-Allow-Headers', "Content-Type");
    next();
})

app.use(session({
    secret: "2C44-4D44-WppQ38S",
    resave: true,
    saveUninitialized: true
}));

// Authentication and Authorization Middleware
var auth = function(req, res, next) {
  if (req.session && req.session.user === "existingUser" )
    return next();
  else
    return res.sendStatus(401);
};
 
// Login endpoint
app.get('/login', function (req, res) {
  if (!req.query.username || !req.query.password) {
    res.send(jsonxml({
						"message": "login failed"
					}));
  } else 
    {
		var q = "select * from bruker where brukerID=? and password =?"
		var params = [req.query.username, md5(req.query.password)]
		

		db.get(q, params, (err, row) => {
			if (err) {
				  res.status(400).send(jsonxml({"error": err.message}));
				  return;
			}
			else if (row){
				req.session.user = "existingUser";
				
				var sql ='INSERT INTO sesjon (brukerID) VALUES (?)'
				var params =[req.query.username]
				db.run(sql, params, function (err, result) {
					if (err){
						res.status(400).send(jsonxml({"error": err.message}))
						return;
					}
					res.send(jsonxml({
						"message": "login success",
						"id" : this.lastID
					}));
				});
			}
			
			else {
				res.send(jsonxml({
						"message": "Feil brukerID eller passord!"}));
			}
		  });
    }
});

// Logout endpoint
app.get('/logout', function (req, res) {
  req.session.destroy();

	var sql ='DELETE from sesjon'
	db.run(sql, function (err, result) {
		if (err){
			res.status(400).send(jsonxml({"error": err.message}))
			return;
		}		
		res.send(jsonxml({
			"message": "logoutn success, all sessions are deleted!"
		}));
	});
});

// Server port
var HTTP_PORT = 9000

// Start server
app.listen(HTTP_PORT, () => {
    console.log("Server running on port %PORT%".replace("%PORT%",HTTP_PORT))
});

// Root endpoint
app.get("/", (req, res, next) => {
	res.send(jsonxml("success", ({"message":"Ok"})));
});

// Other API endpoints
app.get("/api/brukere", auth, (req, res, next) => {
    var sql = "select * from bruker"
    var params = []
    db.all(sql, params, (err, rows) => {
        if (err) {
          res.status(400).send(jsonxml({"error": err.message}));
          return;
        }
		
		res.send(jsonxml({
			"message": "success",
			"data":rows
		}))	
      });
});

app.get("/api/forfattere", (req, res, next) => {
    var sql = "select * from forfatter"
    var params = []
    db.all(sql, params, (err, rows) => {
        if (err) {
          res.status(400).send(jsonxml("error", ({"error": err.message})));
          return;
        }
		res.set('Content-Type', 'text/xml');
		var xmlstring = "<?xml version=1.0 encoding=UTF-8?>" 
		+ "<!DOCTYPE forfatterliste SYSTEM \"http://localhost/forfatterliste.dtd\">"
		+ "<forfatterliste>" + jsonxml(rows) + "</forfatterliste>";
		res.send(xmlstring);
      });
});

app.get("/api/sesjoner", (req, res, next) => {
    var sql = "select * from sesjon"
    var params = []
    db.all(sql, params, (err, rows) => {
        if (err) {
          res.status(400).send(jsonxml({"error": err.message}));
          return;
        }
		res.send(jsonxml({rows}))
      });
});

app.get("/api/boker", (req, res, next) => {
    var sql = "select * from bok"
    var params = []
    db.all(sql, params, (err, rows) => {
        if (err) {
          res.status(400).send(jsonxml({"error": err.message}));
          return;
        }
        var xmlstring = "<?xml version=1.0 encoding=UTF-8?>" 
		+ "<!DOCTYPE bokliste SYSTEM \"http://localhost/bok.dtd\">" 
		+ "<bok>" + jsonxml(rows) + "</bok>";
		res.send(xmlstring);
      });
});


app.get("/api/forfatter/:id", (req, res, next) => {
    var sql = "select * from forfatter where forfatterID =?"
    var params = [req.params.id]
    db.get(sql, params, (err, row) => {
        if (err) {
          res.status(400).send(jsonxml({"error": err.message}));
          return;
        }
		var xmlstring = "<?xml version=1.0?>"
		+ "<!DOCTYPE forfatter \"http://localhost/forfatter.dtd\"> <forfatter>"
		+ jsonxml(row) + '</forfatter>'
		res.send(xmlstring);
      });
});

app.get("/api/bok/:id", (req, res, next) => {
    var sql = "select * from bok where bokID =?"
    var params = [req.params.id]
    db.get(sql, params, (err, row) => {
        if (err) {
          res.status(400).send(jsonxml({"error": err.message}));
          return;
        }
        var xmlstring = "<?xml version=1.0 encoding=UTF-8?>" 
		+ "<!DOCTYPE forfatter SYSTEM \"http://localhost/bok.dtd\">" 
		+ "<bok>" + jsonxml(row) + "</bok>"
		res.send(xmlstring);
      });
});

//Endpoints for authorized users only

app.post("/api/forfatter/", auth, (req, res, next) => {
	
	var forfatterID = req.body["forfatter"]["forfatterID"][0]
	var fornavn = req.body["forfatter"]["fornavn"][0]
	var etternavn = req.body["forfatter"]["etternavn"][0]
	var nasjonalitet = req.body["forfatter"]["nasjonalitet"][0]

	var sql ='INSERT INTO forfatter (forfatterID, fornavn, etternavn, nasjonalitet) VALUES (?,?,?,?)'
		var params =[forfatterID, fornavn, etternavn, nasjonalitet]
		db.run(sql, params, function (err, result) {
        if (err){
            res.status(400).send(jsonxml({"error": err.message}))
            return;
        }
		res.send(jsonxml({"message": "success!"}))
		}); 

})

app.post("/api/bok/", auth, (req, res, next) => {

	var bokID = req.body["bok"]["bokID"][0]
	var titel = req.body["bok"]["titel"][0]
	var forfatterID = req.body["bok"]["forfatterID"][0]
	
    var sql ='INSERT INTO bok (bokID, titel, forfatterID) VALUES (?,?,?)'
    var params =[bokID, titel, forfatterID]
    db.run(sql, params, function (err, result) {
        if (err){
            res.status(400).send(jsonxml("error", ({"error": err.message})))
            return;
        }
		res.send(jsonxml({"message": "success!"}))
    });
})

app.delete("/api/bok/:id", auth, (req, res, next) => {
    db.run(
        'DELETE FROM bok WHERE bokID = ?',
        req.params.id,
        function (err, result) {
            if (err){
                res.status(400).send(jsonxml({"error": res.message}))
                return;
            }			
			res.send(jsonxml({
				"message": "deleted!",
				changes: this.changes
			}))
    });
})

app.delete("/api/forfatter/:id", auth, (req, res, next) => {
    db.run(
        'DELETE FROM forfatter WHERE forfatterID = ?',
        req.params.id,
        function (err, result) {
            if (err){
                res.status(400).send(jsonxml({"error": res.message}))
                return;
            }			
			res.send(jsonxml({
				"message": "deleted!",
				changes: this.changes
			}))
    });
})

app.delete("/api/boker/", auth, (req, res, next) => {
    db.run(
        'DELETE FROM bok',
        function (err, result) {
            if (err){
                res.status(400).send(jsonxml("error", ({"error": res.message})))
                return;
            }
			res.send(jsonxml({
				"message": "all book rows are deleted!",
				changes: this.changes
			}))
    });
})

app.delete("/api/forfattere/", auth, (req, res, next) => {
    db.run(
        'DELETE FROM forfatter',
        function (err, result) {
            if (err){
                res.status(400).send(jsonxml({"error": res.message}))
                return;
            }

			res.send(jsonxml({
				"message": "all author rows are deleted!",
				changes: this.changes
			}))
    });
})

app.patch("/api/forfatter/:id", auth, (req, res, next) => {
	
	var fornavn = req.body["forfatter"]["fornavn"][0]
	var etternavn = req.body["forfatter"]["etternavn"][0]
	var nasjonalitet = req.body["forfatter"]["nasjonalitet"][0]
	
    db.run(
        `UPDATE forfatter set  
           fornavn = COALESCE(?,fornavn), 
           etternavn = COALESCE(?,etternavn),
		   nasjonalitet = COALESCE(?,nasjonalitet)
           WHERE forfatterID = ?`,
        [fornavn, etternavn, nasjonalitet, req.params.id],
        function (err, result) {
            if (err){
                res.status(400).send(jsonxml({"error": res.message}))
                return;
            }		
			res.send(jsonxml({
				"message": "success",
                changes: this.changes
			}))
    });
})

app.patch("/api/bok/:id", auth, (req, res, next) => {
	
	var titel = req.body["bok"]["titel"][0]
	var forfatterID = req.body["bok"]["forfatterID"][0]
	
    db.run(
        `UPDATE bok set  
           titel = COALESCE(?,titel), 
           forfatterID = COALESCE(?,forfatterID)
           WHERE forfatterID = ?`,
        [titel, forfatterID, req.params.id],
        function (err, result) {
            if (err){
                res.status(400).send(jsonxml({"error": res.message}))
                return;
            }		
			res.send(jsonxml({
				"message": "success",
                changes: this.changes
			}))
    });
})

// Default response for any other request
app.use(function(req, res){
    res.status(404);
});
