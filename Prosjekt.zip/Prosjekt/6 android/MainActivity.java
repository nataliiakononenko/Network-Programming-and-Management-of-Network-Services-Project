package com.example.student.start;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import java.util.*;
import android.widget.TextView;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.widget.AdapterView;
import android.app.Activity;

import android.webkit.WebViewClient;

import java.util.ArrayList;

import android.app.Activity;
import android.content.ContentProviderOperation;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.content.ContentResolver;
import android.util.Log;

import android.support.v4.app.ActivityCompat;

import android.support.v4.content.ContextCompat;

import android.content.pm.PackageManager;

import android.Manifest;


public class MainActivity extends android.app.Activity {

    android.os.Handler mHandler = new android.os.Handler();
    android.webkit.WebView wv;
    android.content.Context kontekst = this;
    MinWebChromeKlient wcc = new MinWebChromeKlient();

    @Override
    public void onCreate(android.os.Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        wv = new android.webkit.WebView(this);

        wv.getSettings().setJavaScriptEnabled(true);
        wv.addJavascriptInterface(wcc, "javaobjekt");
        wv.setWebChromeClient(wcc);
        wv.setWebViewClient(new CustomWebViewClient());
        wv.loadUrl("file:///android_asset/start.html");

        setContentView(wv);
    }

    private class CustomWebViewClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    class MinWebChromeKlient extends android.webkit.WebChromeClient {

        @android.webkit.JavascriptInterface
        public String getNameEmailDetails(String u){

            ArrayList<String> names = new ArrayList<String>();
            ContentResolver cr = getContentResolver();
            Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,null, null, null, null);
            if (cur.getCount() > 0) {
                while (cur.moveToNext()) {
                    String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                    Cursor cur1 = cr.query(
                            ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                            ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (cur1.moveToNext()) {
                        //to get the contact names
                        String name=cur1.getString(cur1.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                        Log.e("Name :", name);
                        String email = cur1.getString(cur1.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
                        Log.e("Email", email);
                        if(email != null){
                            names.add(email);
                            names.add(name);
                        }
                    }
                    cur1.close();
                }
            }
            String result = "";

            for(int i=0;i<names.size();i++)
            {
                if (names.get(i).equals(u))
                    result += names.get(i+1);
            }

            return result;
        }
    }
}

